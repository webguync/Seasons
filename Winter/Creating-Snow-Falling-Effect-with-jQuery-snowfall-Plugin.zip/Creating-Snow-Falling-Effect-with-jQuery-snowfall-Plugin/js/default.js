$(document).ready(function() {

	 //Initialize our snowfall plugin on the canvas element
	 $("#snowfall").Snowfall();
});